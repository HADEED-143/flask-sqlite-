CREATE TABLE `liveconver` (
  `serialno` INTEGER NOT NULL,
  `customername` TEXT NOT NULL,
  `bandwidht` INTEGER NOT NULL,
  PRIMARY KEY("user_id" AUTOINCREMENT)
);

INSERT INTO `liveconver`
  (`serialno`, `customername`,`bandwidht`)
VALUES
  ("1", "john","12"),
  ("2", "jone","12"),
  ("3", "joke","12"),
  ("4", "Joger","12"),
  ("5", "join","12"),

